import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Program {

	public static void main(String args[]) {
		char r;
		do {
			
		System.out.println("********** Librarian Ledger***********");
		System.out.println("Press 1 to add Book");
		System.out.println("Press 2 to issue a Book");
		System.out.println("Press 3 to return a Book");
		System.out.println("Press 4 to print complete issue details");
		System.out.println("Press 5 to exit");
		Scanner obj1 = new Scanner(System.in);
		System.out.println("Enter any number");
		int a=obj1.nextInt();		
		
		switch(a)
		{
		case 1:
			Library aa=new Library();
			aa.add();
			break;
		case 2:
			Library bb=new Library();
			bb.issue();
			break;
		case 3:
			Library cc=new Library();
			cc.ReturnBooks();
			break;
		case 4:
			Library is=new Library();
			is.detail();
			break;
		case 5:
			Library add=new Library();
			add.exit();
			break;
			default:
				System.out.println("Invalid number");
			
		}
		System.out.println("You have to select the next option Y/N");
		r=obj1.next().charAt(0);
		}while(r=='y'||r=='Y');
		if(r=='n'||r=='N')
		{
			Library z=new Library();
			z.exit();
		}
	}
}

class Library
{
	static String bookName, bookDate, returnBookDate;
	static int bookId, numberOfBooksIssued, isIssued;
	FileIO io = new FileIO();
	
	void add()
	{
		
		System.out.println("Book ID, Enter Book Name");
		Scanner input = new Scanner(System.in);
		bookId = input.nextInt();
		
		bookName = input.nextLine();
		
		File file = new File("ledger.txt");
		FileWriter fr = null;
		if(!file.exists()) {
			io.CreateFile();
			io.WriteToFile(bookName, bookId);
			io.CloseFile();
		}
		else {
			try {
				fr = new FileWriter(file, true);
				fr.append("\r\n");
				fr.append("\n"+bookName + "\t" + bookId);
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	void issue()
	{
		Scanner inputIssuer = new Scanner(System.in);
		System.out.println("Book Name");
		bookName = inputIssuer.nextLine();
		System.out.println("Book Id");
		bookId= inputIssuer.nextInt();
		System.out.println("Issue Date");
		bookDate = inputIssuer.nextLine();
		System.out.println("Total Number of Books Issued");
		numberOfBooksIssued = inputIssuer.nextInt();
		System.out.println("Return book date");
		returnBookDate = inputIssuer.nextLine();
	}
	int getBookID()
	{
		return bookId; 
	}
	
	void ReturnBooks()
	{
		System.out.println("Enter Student_name & Book_id");
		Scanner inputReturnBooks  = new Scanner(System.in);
		String name = inputReturnBooks.nextLine();
		int _bookid = inputReturnBooks.nextInt();
			if(bookId == _bookid)
			{
				System.out.println("Total Details");
				System.out.println("Book Name:"+ Library.bookName);
				System.out.println("Book id:"+ Library.bookId);
				System.out.println("Issue Date"+Library.bookDate);
				System.out.println("Total number of books Issued"+Library.numberOfBooksIssued);
				System.out.println("Book Return Date:"+ Library.returnBookDate);
				
			}
			else
			{
				System.out.println("Wrong Id, Please Enter correct book ID");
			}
		}
	void detail()
	{
		System.out.println("Book Name::"+ Library.bookName);
		System.out.println("Book id ::"+ Library.bookId);
		System.out.println("Issue Date"+Library.bookDate);
		System.out.println("Total number of books Issued::"+Library.numberOfBooksIssued);
		System.out.println("Book Return Date:"+ Library.returnBookDate);
	}

	void exit()
	{
		System.exit(0);
	}
}