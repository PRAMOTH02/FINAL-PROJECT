import java.util.*;
import java.lang.*;
import java.io.*;
public class FileIO {

	private Formatter formatter;
	private Scanner fileScanner;
	public void CreateFile() {
	 try {
		 formatter = new Formatter("libmanagement.txt");
	 }
	 catch(Exception e) {
		 System.out.println("An error occured");
	 }
	}
	
	public void WriteToFile(String bookName, int bookNo) {
		formatter.format("%s\t%d", bookName, bookNo);
	}
	
	public void CloseFile() {
		formatter.close();
	}
	
	public void ReadFile()
	{
		try {
			fileScanner = new Scanner(new File("libmanagement.txt"));			
			while(fileScanner.hasNext())
			{
				String bookName = fileScanner.next();
			    int bookId = Integer.parseInt(fileScanner.next());
				//String bookDate = fileScanner.next();
				//String bookReturnDate = fileScanner.next();
				
				System.out.printf("%d %s",bookId, bookName);
				
			}
		}
	catch(Exception ex) {
		System.out.println("An error occured");
	}
}
}
